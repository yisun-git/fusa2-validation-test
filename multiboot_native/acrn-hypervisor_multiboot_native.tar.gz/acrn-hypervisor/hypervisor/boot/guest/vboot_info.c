/*
 * Copyright (C) 2019 Intel Corporation. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include <types.h>
#include <rtl.h>
#include <errno.h>
#include <per_cpu.h>
#include <irq.h>
#include <boot_context.h>
#include <multiboot.h>
#include <pgtable.h>
#include <zeropage.h>
#include <mmu.h>
#include <vm.h>
#include <logmsg.h>
#include <vboot_info.h>

/**
 * @defgroup vp-base_vboot vp-base.vboot
 * @ingroup vp-base
 * @brief Implementation of vboot releated utility functions and APIs to collect the base addresses where the OS
 * kernel images and boot-time arguments of each guest VM is currently placed, sizes of these images and the guest
 * physical addresses where the OS kernel images shall be loaded.
 *
 * This module interacts with with the following modules:
 *
 *    - hwmgmt.page
 *
 *      Use the hwmgmt.base module to do address translation between host physical address and host virtual address
 *
 *      All the APIs used in hwmgmt.page module listing below:
 *
 *          + hpa2hva
 *
 *    - hwmgmt.cpu
 *
 *      Use the hwmgmt.cpu module to allow the hypervisor to access memory regions allocated to VMs.
 *
 *          + stac
 *          + clac
 *
 *    - hwmgmt.configs
 *
 *      Use the hwmgmt.configs module to get the vm configuration data.
 *      All the APIs used in hwmgmt.configs module listing below:
 *
 *          + get_vm_config
 *
 *    - lib.utils
 *
 *      Use the lib.utils module to calculate string lengths and compare strings.
 *
 *      All the APIs used in lib.utils module listing below:
 *          + strnlen_s
 *          + strncmp
 *
 *    - debug
 *
 *      Use the debug module to log a message in debug version, do nothing in release version.
 *      All the APIs used in debug module listing below:
 *
 *          + dev_dbg
 *
 * This module is decomposed into the following files:
 *
 *     vboot_info.c        -Implements all APIs that shall be provided by the vp-base.vboot
 *     vboot_info.h        -Declares all APIs that shall be provided by the vp-base.vboot
 *
 * @{
 */

/**
 * @file
 * @brief This file implements all APIs that shall be provided by the vp-base.vboot
 *
 * This file is decomposed into the following functions:
 *
 *     init_vm_boot_info         -Initialize virtual platform boot info
 *     get_mod_idx_by_tag        -Using tag to find the matching module embedded in module structure array
 *     init_vm_bootargs_info     -Initialize virtual machine bootargs_info field.
 *     init_vm_kernel_info       -Initialize the virtual machine kernel_info field of the given argument \a vm
 *     get_kernel_load_addr      -Get guest physical address where the kernel image will be placed to
 */

/**
 * @brief The severity of console log level
 *
 * Specify the console level of debugging messages in this module
 */
#define ACRN_DBG_BOOT 6U

/**
 * @brief The invalid index of module structure array
 */
#define INVALID_MOD_IDX 0xFFFFU

/**
 * @brief Get guest physical address where the kernel image will be placed to
 *
 * This function returns the guest physical address where the OS kernel of this VM shall be placed to
 *
 * @param[in] vm a pointer to VM whose guest physical address where the kernel image will be placed to, will be
 * collected and return.
 *
 * @return a value representing kernel loading address
 *
 * @pre vm != NULL
 * @pre vm->vm_id < CONFIG_MAX_VM_NUM
 * @pre get_vm_config(vm->vm_id)->os_config.kernel_type == KERNEL_BZIMAGE ||
 * get_vm_config(vm->vm_id)->os_config.kernel_type == KERNEL_ZEPHYR
 * @pre get_vm_config(0)->os_config.kernel_load_addr !=NULL
 * @pre get_vm_config(0)->os_config.kernel_entry_addr != NULL
 *
 * @mode HV_SUBMODE_INIT_ROOT
 *
 * @reentrancy unspecified
 * @threadsafety \a vm is different among parallel invocation
 */
static uint64_t get_kernel_load_addr(struct acrn_vm *vm)
{
	/** Declare the following local variables of type void *.
	 *  - load_addr representing the guest physical address where the kernel image will be placed to, initialized
	 *    as 0UL. */
	uint64_t load_addr = 0UL;
	/** Declare the following local variables of type struct vm_sw_info *.
	 *  - sw_info representing the VM software information structure given by vm, initialized as &vm->sw. */
	struct vm_sw_info *sw_info = &vm->sw;
	/** Declare the following local variables of type struct zero_page *.
	 *  - zeropage representing the kernel header of the OS kernel image of the given VM, where the kernel header
	 *    is in compliance with linux kernel boot protocol */
	struct zero_page *zeropage;
	/** Declare the following local variables of type struct acrn_vm_config *.
	 *  - vm_config representing the virtual platform configuration structure of the given VM, initialized as
	 *    get_vm_config(vm->vm_id). */
	struct acrn_vm_config *vm_config = get_vm_config(vm->vm_id);

	/** Depending on the kenrel_type field of sw_info */
	switch (sw_info->kernel_type) {
	/** kernel type is KERNEL_BZIMAGE */
	case KERNEL_BZIMAGE:
		/* According to the explaination for pref_address
		 * in Documentation/x86/boot.txt, a relocating
		 * bootloader should attempt to load kernel at pref_address
		 * if possible. A non-relocatable kernel will unconditionally
		 * move itself and to run at this address, so no need to copy
		 * kernel to perf_address by bootloader, if kernel is
		 * non-relocatable.
		 */
		/** Set zeropage to the kernel_src_addr field of kernel_info of sw_info, where zeropage structure is a
		 *  linux kernel boot protocol header in the beginning of the guest OS kernel image */
		zeropage = (struct zero_page *)sw_info->kernel_info.kernel_src_addr;
		/** Set load_addr to the pref_addr field in the header of zeropage */
		load_addr = zeropage->hdr.pref_addr;
		/** End of case */
		break;
	/** kernel type is KERNEL_ZEPHYR */
	case KERNEL_ZEPHYR:
		/** Set load_addr to the kernel_load_addr field of os_config of vm_config */
		load_addr = vm_config->os_config.kernel_load_addr;
		/** End of case */
		break;
	/** Otherwise */
	default:
		/* kernel type is either KERNEL_BZIMAGE or KERNEL_ZEPHYR, do nothing here */
		/** Unexpected case. Break gracefully without changing load_addr as a defensive action. */
		break;
	}

	/** Return the guest physical address where the kernel image will be placed to */
	return load_addr;
}

/**
 * @brief Initialize the virtual machine kernel_info field of the given argument \a vm
 *
 * @param[inout] vm a pointer to VM whose kernel information will be initialized, where the kernel information
 * including list below:
 * - the base address where the OS kernel image is
 * - the size of kernel image
 * - the guest physical address where the OS kernel image shall be loaded
 * @param[in] mod pointer to multiboot module structure
 *
 * @return None
 *
 * @pre vm != NULL && mod != NULL
 * @pre vm->vm_id < CONFIG_MAX_VM_NUM
 * @pre get_vm_config(vm->vm_id)->os_config.kernel_type == KERNEL_BZIMAGE ||
 * get_vm_config(vm->vm_id)->os_config.kernel_type == KERNEL_ZEPHYR
 * @pre get_vm_config(0)->os_config.kernel_load_addr !=NULL
 * @pre get_vm_config(0)->os_config.kernel_entry_addr != NULL
 *
 * @mode HV_SUBMODE_INIT_ROOT
 *
 * @reentrancy unspecified
 * @threadsafety \a vm is different among parallel invocation
 */
static void init_vm_kernel_info(struct acrn_vm *vm, const struct multiboot_module *mod)
{
	/** Declare the following local variables of type struct acrn_vm_config *.
	 *  - vm_config representing the virtual platform configuration structure of the given VM, initialized as
	 *    get_vm_config(vm->vm_id). */
	struct acrn_vm_config *vm_config = get_vm_config(vm->vm_id);

	/** Logging the following information with a log level of ACRN_DBG_BOOT.
	 *  - mod->mm_mod_start
	 *  - mod->mm_mod_end */
	dev_dbg(ACRN_DBG_BOOT, "kernel mod start=0x%x, end=0x%x", mod->mm_mod_start, mod->mm_mod_end);

	/** Set the kernel_type field of sw field of vm to the kernel_type field of os_config of vm_config */
	vm->sw.kernel_type = vm_config->os_config.kernel_type;
	/** Set the kernel_src_addr field of kernel_info of vm's sw field to the host virtual address translated
	 *  from the module start address in mod */
	vm->sw.kernel_info.kernel_src_addr = hpa2hva((uint64_t)mod->mm_mod_start);
	/** Set the kernel_size field of kernel_info of vm's sw field to the value calculated by subtracting the
	 *  mm_mod_start field from the mm_mod_end field in mod */
	vm->sw.kernel_info.kernel_size = mod->mm_mod_end - mod->mm_mod_start;
	/** Set the kernel_load_addr field of kernel_info of vm's sw field to get_kernel_load_addr(vm) */
	vm->sw.kernel_info.kernel_load_addr = get_kernel_load_addr(vm);
}

/**
 * @brief Initialize virtual machine bootargs_info field.
 *
 * @param[inout] vm a pointer to VM whose boot-time information will be initialized, where boot-time information
 * including list below:
 * - the host virtual address where placed boot-time arguments of the given VM
 - - the size of the boot-time arguments of the given VM
 * - the guest physical address where boot-time arguments will be placed.
 *
 * @return None
 *
 * @pre vm != NULL
 * @pre vm->vm_id < CONFIG_MAX_VM_NUM
 *
 * @mode HV_SUBMODE_INIT_ROOT
 *
 * @reentrancy unspecified
 * @threadsafety \a vm is different among parallel invocation
 */
static void init_vm_bootargs_info(struct acrn_vm *vm)
{
	/** Declare the following local variables of type struct acrn_vm_config *.
	 *  - vm_config representing the virtual platform configuration structure of the given VM, initialized as
	 *    get_vm_config(vm->vm_id). */
	struct acrn_vm_config *vm_config = get_vm_config(vm->vm_id);
	/** Declare the following local variables of type char *.
	 *  - bootargs representing the boot argument of virtual machine, initialized as
	 *    vm_config->os_config.bootargs;*/
	char *bootargs = vm_config->os_config.bootargs;

	/** Set the src_addr field of bootargs_info of vm's sw field to bootargs */
	vm->sw.bootargs_info.src_addr = bootargs;
	/** Set the size field of bootargs_info of vm's sw field to strnlen_s(bootargs, MAX_BOOTARGS_SIZE) */
	vm->sw.bootargs_info.size = strnlen_s(bootargs, MAX_BOOTARGS_SIZE);

	/* Kernel bootarg and zero page are right before the kernel image */
	/** If the size field of bootargs of vm's sw is greater than 0 */
	if (vm->sw.bootargs_info.size > 0U) {
		/** Set the load_addr field of bootargs_info of vm's sw field to the address that calculated by
		 *  subtracting 8K from the kernel_load_addr field of kernel_info of vm's sw field */
		vm->sw.bootargs_info.load_addr = vm->sw.kernel_info.kernel_load_addr - (MEM_1K * 8U);
	} else {
		/** Set the load_addr field of bootargs_info of vm's sw field to NULL */
		vm->sw.bootargs_info.load_addr = 0UL;
	}
}

/**
 * @brief Using \a tag to find the matching module embedded in module structure array
 *
 * Finding the matching module by iterating module embedded in module structure array by comparing the string
 * field of each module with the \a tag string.
 *
 * @param[in] mods pointer to multiboot module structure array
 * @param[in] mods_count an integer value indicating the amount of module structures that embedded in the module
 * structure array.
 * @param[in] tag a string used to find the matching module.
 *
 * @return the found index by using \a tag to find the matching module embedded in \a mods.
 *
 * @pre mods != NULL
 * @pre tag != NULL
 *
 * @mode HV_SUBMODE_INIT_ROOT
 *
 * @reentrancy unspecified
 * @threadsafety yes
 */
static uint32_t get_mod_idx_by_tag(const struct multiboot_module *mods, uint32_t mods_count, const char *tag)
{
	/** Declare the following local variables of type uint32_t.
	 *  - i representing iteration number.
	 *  - ret representing the return value of get_mod_idx_by_tag, initialized as INVALID_MOD_IDX. */
	uint32_t i, ret = INVALID_MOD_IDX;
	/** Declare the following local variables of type uint32_t.
	 *  - tag_len representing the string length of argument tag, initialized as
	 *    strlen_s(tag, MAX_MOD_TAG_LEN). */
	uint32_t tag_len = strnlen_s(tag, MAX_MOD_TAG_LEN);

	/** For each i ranging from 0 to mods_count [with a step of 1] */
	for (i = 0U; i < mods_count; i++) {
		/** Declare the following local variables of type const char *.
		 *  - mm_string representing the mm_string field of the ith entry in mods, initialized as
		 *    hpa2hva(mods[i].mm_string). */
		const char *mm_string = (char *)hpa2hva((uint64_t)mods[i].mm_string);
		/** Declare the following local variables of type uint32_t.
		 *  - mm_str_len representing the string length of mm_string field of the ith entry in mods,
		 *    initialized as strnlen_s(mm_string, MAX_MOD_TAG_LEN). */
		uint32_t mm_str_len = strnlen_s(mm_string, MAX_MOD_TAG_LEN);

		/* when do file stitch by tool, the tag in mm_string might be followed with 0x0d or 0x0a */
		/** If mm_str_len is greater than tag_len
		 *  and the first tag_len characters in mm_string are the same as tag
		 *  and the content of mm_string[tag_len] is equal to 0x0d/0x0a/0 */
		if ((mm_str_len >= tag_len) && (strncmp(mm_string, tag, tag_len) == 0) &&
			((*(mm_string + tag_len) == 0x0d) || (*(mm_string + tag_len) == 0x0a) ||
				(*(mm_string + tag_len) == 0))) {
			/** Set ret to i */
			ret = i;
			/** Terminate the loop */
			break;
		}
	}
	/** Return the found index of module structure array */
	return ret;
}

#define MULTIBOOT_NATIVE_TEST
#ifdef MULTIBOOT_NATIVE_TEST
#define NON_SAFETY_VM_MOD_TAG			"linux"
#define SAFETY_VM_MOD_TAG				"zephyr"
#define MULTIBOOT_FLAG					0x48
#define MULTIBOOT_MOD_NUM				0x2
#define NON_SAFETY_PREF_ADDRESS			0x1000000
#define NON_SAFETY_ENTRY_POINT			0x1000600
#define SAFETY_ENTRY_POINT				0x100000
#define NON_SAFETY_RELOCATABLE_KERNEL	0x1
#define MULTIBOOT_FIRST_MOD_ID			0x0
#define MULTIBOOT_SECOND_MOD_ID			0x1
#define NON_SAFETY_IMAGE_LEN			0x1371C
#define NON_SAFETY_IMAGE_CHECKSUM		0x7
#define SAFETY_IMAGE_LEN				0x1039C
#define SAFETY_IMAGE_CHECKSUM			0x99
#define MULTIBOOT_MAGIC					0x2BADB002
#define CODE_TYPE_READ_BIT				(0x2)
#define DATA_TYPE_WRITE_BIT				(0x2)

extern unsigned char boot_context[];
extern uint32_t save_eflags;
struct descriptor_table_ptr {
	uint16_t limit;
	unsigned long base;
} __attribute__((packed));

unsigned char multiboot_checksum(unsigned long point, unsigned long size)
{
	unsigned char sum = 0;
	unsigned char *p = (unsigned char *)point;
	unsigned long i;

	for (i = 0; i < size; i++) {
		sum += p[i];
	}

	return sum;
}

/* requirement 198890 */
/**
 * @brief case name:module tag of linux_001
 *
 * Summary: After grub loads ACRN and module, read the module information in
 * multiboot provided by grub, which contains 'linux' module
 */
void multiboot_rqmid_39353_linux_mod(uint32_t mod_idx)
{
	pr_fatal("%s %s mod_idx=%d\n", (mod_idx == MULTIBOOT_SECOND_MOD_ID)?"pass":"fail",
		__FUNCTION__, mod_idx);
}

/* requirement 146047 */
/**
 * @brief case name: Second boot module from physical platform_001
 *
 * Summary: After grub loads ACRN and module, read the module information
 * in multiboot provided by grub, the second module is non-safety VM.
 */
void multiboot_rqmid_39358_second_boot(uint32_t mod_idx)
{
	pr_fatal("%s %s mod_idx=%d\n", (mod_idx == MULTIBOOT_SECOND_MOD_ID)?"pass":"fail",
		__FUNCTION__, mod_idx);
}

/* requirement 146044 */
/**
 * @brief case name: Physical platform Multiboot information data structure_001
 *
 * Summary: The physical platform shall set flags field of multiboot information structure to 48H.
 */
void multiboot_rqmid_39375_multiboot_flags(uint32_t mi_flags)
{
	pr_fatal("%s %s mi_flags=0x%x\n", ((mi_flags & MULTIBOOT_FLAG) == MULTIBOOT_FLAG)?"pass":"fail",
		__FUNCTION__, mi_flags);
}

/* requirement 144601 */
/**
 * @brief case name: boot modules information_001
 *
 * Summary: If bit 3 of the 'flags is set, then the 'mods fields indicate to the
 * kernel what boot modules were loaded along with the kernel image, and where they
 * can be found. 'mods_count' contains the number of modules loaded
 */
void multiboot_rqmid_39376_boot_modules(uint32_t mi_mods_count)
{
	pr_fatal("%s %s mi_mods_count=%d\n", (mi_mods_count == MULTIBOOT_MOD_NUM)?"pass":"fail",
		__FUNCTION__, mi_mods_count);
}

/* requirement 144600 */
/**
 * @brief case name: memory map information of the physical platform_001
 *
 * Summary:  If bit 6 in the 'flags word is set, then the 'mmap_*' fields are valid,
 * and indicate the address and length of a buffer containing a memory
 * map of the machine provided by the bios.
 */
void multiboot_rqmid_39377_memory_map(struct multiboot_info *mbi)
{
	uint32_t mem_entry;

	/* flags bit 6 is set */
	if ((mbi->mi_flags & MULTIBOOT_INFO_HAS_MMAP) != 0U) {
		mem_entry = mbi->mi_mmap_length / sizeof(struct multiboot_mmap);
		pr_fatal("%s %s em_entry=%d\n", (mem_entry != 0)?"pass":"fail",
			__FUNCTION__, mem_entry);
	}
}

/* requirement 145189 */
/**
 * @brief case name: Bootloader shall configurate modules_001
 *
 * Summary: The non-safety kernel image file length calculated by multiboot
 * is consistent with the original non-safety kernel image file,
 * and the check sum is used to verify that the file has not been modified
 */
void multiboot_rqmid_39380_memory_map(struct multiboot_module *mods)
{
	uint64_t len;
	unsigned char check_sum;

	len = mods[MULTIBOOT_SECOND_MOD_ID].mm_mod_end - mods[MULTIBOOT_SECOND_MOD_ID].mm_mod_start;
	check_sum = multiboot_checksum((unsigned long)mods[MULTIBOOT_SECOND_MOD_ID].mm_mod_start, len);
	pr_fatal("%s %s len=0x%lx, check_sum=0x%x\n",
		((len == NON_SAFETY_IMAGE_LEN) && (check_sum == NON_SAFETY_IMAGE_CHECKSUM))?"pass":"fail",
		__FUNCTION__, len, check_sum);
}

/* requirement 198889 */
/**
 * @brief case name: module tag of zephyr_001
 *
 * Summary: After grub loads ACRN and module, read the module information
 * in multiboot provided by grub, which contains 'zephyr' module
 */
void multiboot_rqmid_39355_zephyr_mod(uint32_t mod_idx)
{
	pr_fatal("%s %s mod_idx = %d\n", (mod_idx == MULTIBOOT_FIRST_MOD_ID)?"pass":"fail",
		__FUNCTION__, mod_idx);
}

/* requirement 146046 */
/**
 * @brief case name: First boot module from physical platform_001
 *
 * Summary: After grub loads ACRN and module, read the module information
 * in multiboot provided by grub, the first module is safety VM.
 */
void multiboot_rqmid_39359_first_boot(uint32_t mod_idx)
{
	pr_fatal("%s %s mod_idx = %d\n", (mod_idx == MULTIBOOT_FIRST_MOD_ID)?"pass":"fail",
		__FUNCTION__, mod_idx);
}

/* requirement 145189 */
/**
 * @brief case name: Bootloader shall configurate modules_002
 *
 * Summary: The safety kernel image file length calculated by multiboot
 * is consistent with the original safety kernel image file,
 * and the check sum is used to verify that the file has not been modified
 */
void multiboot_rqmid_39395_memory_map(struct multiboot_module *mods)
{
	unsigned long len;
	uint32_t check_sum;

	len = mods[MULTIBOOT_FIRST_MOD_ID].mm_mod_end - mods[MULTIBOOT_FIRST_MOD_ID].mm_mod_start;
	check_sum = multiboot_checksum((unsigned long)mods[MULTIBOOT_FIRST_MOD_ID].mm_mod_start, len);
	pr_fatal("%s %s len=0x%lx, check_sum=0x%x\n",
		((len == SAFETY_IMAGE_LEN) && (check_sum == SAFETY_IMAGE_CHECKSUM))?"pass":"fail",
		__FUNCTION__, len, check_sum);
}

/* requirement 187079 */
/**
 * @brief case name: the pref_address field of zero-page_001
 *
 * Summary: The pref_address field of zero-page of non-safety
 * VM kernel image shall be 1000000H.
 */
void multiboot_rqmid_39356_pref_address(struct zero_page *zeropage)
{
	uint64_t load_addr = 0UL;

	load_addr = zeropage->hdr.pref_addr;
	pr_fatal("%s %s pref_addr = 0x%lx\n", (load_addr == NON_SAFETY_PREF_ADDRESS)?"pass":"fail",
		__FUNCTION__, load_addr);
}


/* requirement 187078 */
/**
 * @brief case name: relocatable_kernel field of setup header_001
 *
 * Summary: The relocatable_kernel field of setup header of
 * zero page of non-safety VM kernel image shall be 1H.
 */
void multiboot_rqmid_39357_relocatable_address(struct zero_page *zeropage)
{
	pr_fatal("%s %s relocatable_kernel = 0x%x\n",
		(zeropage->hdr.relocatable_kernel == NON_SAFETY_RELOCATABLE_KERNEL)?"pass":"fail",
		__FUNCTION__, zeropage->hdr.relocatable_kernel);
}

/* requirement 145198 */
/**
 * @brief case name: non-safety vm entry point_001
 *
 * Summary: The entry point of kenel image of non-safety VM shall be (the value of
 * setup_sects of setup header of zero page of kernel image + 1H) * 200H + 1000000H.
 */
void multiboot_rqmid_39379_non_safety_entry_point(struct zero_page *zeropage)
{
	uint64_t entry_point = 0UL;

	entry_point = (zeropage->hdr.setup_sects + 1) * 0x200 + NON_SAFETY_PREF_ADDRESS;
	pr_fatal("%s %s entry_point = 0x%x\n", (entry_point == NON_SAFETY_ENTRY_POINT)?"pass":"fail",
		__FUNCTION__, entry_point);
}

/* requirement 146125 */
/**
 * @brief case name: entry point of kernel image of safety VM_001
 *
 * Summary: The physical address of entry point of kernel
 * image of safety VM shall be 100000H.
 */
void multiboot_rqmid_39378_safety_entry_point(struct acrn_vm_config *vm_config)
{
	uint64_t entry_point = 0UL;

	entry_point = vm_config->os_config.kernel_load_addr;
	pr_fatal("%s %s entry_point = 0x%x\n", (entry_point == SAFETY_ENTRY_POINT)?"pass":"fail",
		__FUNCTION__, entry_point);
}

//requirement 144602
/**
 * @brief case name: physical the machine state_001
 *
 * Summary: The physical platform shall set the machine state
 * in compliance with Chapter 3.2, Multiboot Spec 0.6.96.
 */
void multiboot_rqmid_39381_machine_state()
{
	bool ret = true;
	struct multiboot_info *mbi;
	uint16_t cs, ds, es, fs, gs, ss;
	uint32_t a20_gate[2];
	uint32_t cr0;
	uint16_t point_short;
	uint32_t point_int;
	struct descriptor_table_ptr *gdtr;
	uint64_t *gdt;
	uint32_t base;
	uint32_t limit;
	uint32_t type;

	/* EAX contain the magic value '0x2BADB002' */
	if (boot_regs[0] != MULTIBOOT_MAGIC) {
		ret = false;
		pr_fatal("multiboot_magic=0x%x\n", boot_regs[0]);
	}

	/*EBX contain the 32-bit physical address of the Multiboot
	 *information structure provided by the boot loader
	 */
	mbi = (struct multiboot_info *)hpa2hva((uint64_t)boot_regs[1]);
	if (((mbi->mi_flags & MULTIBOOT_FLAG) != MULTIBOOT_FLAG)) {
		ret = false;
		pr_fatal("mi_flags=0x%x\n", mbi->mi_flags);
	}

	gdtr = (struct descriptor_table_ptr *)&boot_context[BOOT_CTX_GDT_OFFSET];

	/* cs base is 0, limit is 0xFFFFF*/
	cs = *(uint16_t *)&boot_context[BOOT_CTX_CS_SEL_OFFSET];
	gdt = (uint64_t *)(gdtr->base + cs);
	base = ((*gdt>>16)&0xFFFF) | (((*gdt>>32)&0xFF)<<16) | (((*gdt>>56)&0xFF)<<24);
	limit = (*gdt&0xFFFF) | (((*gdt>>48)&0xF)<<16);
	type = ((*gdt>>40)&0xF);
	if ((base != 0) || (limit != 0xFFFFF) || ((type&CODE_TYPE_READ_BIT) != CODE_TYPE_READ_BIT)) {
		ret = false;
		pr_fatal("cs=0x%x value=0x%lx base=0x%x limit=0x%x\n", cs, *gdt, base, limit);
	}

	/* ds base is 0, limit is 0xFFFFF*/
	ds = *(uint16_t *)&boot_context[BOOT_CTX_DS_SEL_OFFSET];
	gdt = (uint64_t *)(gdtr->base + ds);
	base = ((*gdt>>16)&0xFFFF) | (((*gdt>>32)&0xFF)<<16) | (((*gdt>>56)&0xFF)<<24);
	limit = (*gdt&0xFFFF) | (((*gdt>>48)&0xF)<<16);
	type = ((*gdt>>40)&0xF);
	if ((base != 0) || (limit != 0xFFFFF) || ((type&DATA_TYPE_WRITE_BIT) != DATA_TYPE_WRITE_BIT)) {
		ret = false;
		pr_fatal("ds=0x%x value=0x%lx base=0x%x limit=0x%x\n", ds, *gdt, base, limit);
	}

	/* es base is 0, limit is 0xFFFFF*/
	es = *(uint16_t *)&boot_context[BOOT_CTX_ES_SEL_OFFSET];
	gdt = (uint64_t *)(gdtr->base + es);
	base = ((*gdt>>16)&0xFFFF) | (((*gdt>>32)&0xFF)<<16) | (((*gdt>>56)&0xFF)<<24);
	limit = (*gdt&0xFFFF) | (((*gdt>>48)&0xF)<<16);
	type = ((*gdt>>40)&0xF);
	if ((base != 0) || (limit != 0xFFFFF) || ((type&DATA_TYPE_WRITE_BIT) != DATA_TYPE_WRITE_BIT)) {
		ret = false;
		pr_fatal("es=0x%x value=0x%lx base=0x%x limit=0x%x\n", es, *gdt, base, limit);
	}

	/* fs base is 0, limit is 0xFFFFF*/
	fs = *(uint16_t *)&boot_context[BOOT_CTX_FS_SEL_OFFSET];
	gdt = (uint64_t *)(gdtr->base + fs);
	base = ((*gdt>>16)&0xFFFF) | (((*gdt>>32)&0xFF)<<16) | (((*gdt>>56)&0xFF)<<24);
	limit = (*gdt&0xFFFF) | (((*gdt>>48)&0xF)<<16);
	type = ((*gdt>>40)&0xF);
	if ((base != 0) || (limit != 0xFFFFF) || ((type&DATA_TYPE_WRITE_BIT) != DATA_TYPE_WRITE_BIT)) {
		ret = false;
		pr_fatal("fs=0x%x value=0x%lx base=0x%x limit=0x%x\n", fs, *gdt, base, limit);
	}

	/* gs base is 0, limit is 0xFFFFF*/
	gs = *(uint16_t *)&boot_context[BOOT_CTX_GS_SEL_OFFSET];
	gdt = (uint64_t *)(gdtr->base + gs);
	base = ((*gdt>>16)&0xFFFF) | (((*gdt>>32)&0xFF)<<16) | (((*gdt>>56)&0xFF)<<24);
	limit = (*gdt&0xFFFF) | (((*gdt>>48)&0xF)<<16);
	type = ((*gdt>>40)&0xF);
	if ((base != 0) || (limit != 0xFFFFF) || ((type&DATA_TYPE_WRITE_BIT) != DATA_TYPE_WRITE_BIT)) {
		ret = false;
		pr_fatal("gs=0x%x value=0x%lx base=0x%x limit=0x%x\n", gs, *gdt, base, limit);
	}

	/* ss base is 0, limit is 0xFFFFF*/
	ss = *(uint16_t *)&boot_context[BOOT_CTX_SS_SEL_OFFSET];
	gdt = (uint64_t *)(gdtr->base + ss);
	base = ((*gdt>>16)&0xFFFF) | (((*gdt>>32)&0xFF)<<16) | (((*gdt>>56)&0xFF)<<24);
	limit = (*gdt&0xFFFF) | (((*gdt>>48)&0xF)<<16);
	type = ((*gdt>>40)&0xF);
	if ((base != 0) || (limit != 0xFFFFF) || ((type&DATA_TYPE_WRITE_BIT) != DATA_TYPE_WRITE_BIT)) {
		ret = false;
		pr_fatal("ss=0x%x value=0x%lx base=0x%x limit=0x%x\n", ss, *gdt, base, limit);
	}

	/* If the address greater than 1M can be accessed, A20 enable */
	a20_gate[0] = a20_gate[1] = MULTIBOOT_MAGIC;
	a20_gate[0] = *(uint32_t *)(0x100000);
	a20_gate[1] = *(uint32_t *)(0x100004);
	if ((a20_gate[0] == MULTIBOOT_MAGIC) && (a20_gate[1] == MULTIBOOT_MAGIC)) {
		ret = false;
	}

	/* CR0 Bit 31 (PG) must be cleared. Bit 0 (PE) must be set */
	cr0 = *(uint32_t *)&boot_context[BOOT_CTX_CR0_OFFSET];
	if ((cr0>>31 != 0) || (cr0&0x1 != 1)) {
		ret = false;
		pr_fatal("cr0=0x%x\n", cr0);
	}

	/* EFLAGS Bit 17 (VM) must be cleared. Bit 9 (IF) must be cleared */
	if (((save_eflags>>17)&0x1 != 0) || ((save_eflags>>9)&0x1 != 0)) {
		ret = false;
		pr_fatal("eflags=0x%x\n", save_eflags);
	}

	pr_fatal("%s %s ret = %s\n", (ret == true)?"pass":"fail",
		__FUNCTION__, (ret == true)?"true":"fail");
}

void srs_multiboot_test(struct acrn_vm *vm)
{
	struct multiboot_info *mbi = (struct multiboot_info *)hpa2hva((uint64_t)boot_regs[1]);
	struct multiboot_module *mods = NULL;
	uint32_t mod_idx = INVALID_MOD_IDX;
	struct zero_page *zeropage;
	struct acrn_vm_config *vm_config = get_vm_config(vm->vm_id);
	struct vm_sw_info *sw_info = &vm->sw;

	stac();

	/* flags bit 3 is set */
	if ((mbi->mi_flags & MULTIBOOT_INFO_HAS_MODS) != 0U) {
		mods = (struct multiboot_module *)hpa2hva((uint64_t)mbi->mi_mods_addr);
		if (mods == NULL) {
			return;
		}
	}

	//non-safety
	if (vm->vm_id == 1)	{
		mod_idx = get_mod_idx_by_tag(mods, mbi->mi_mods_count, NON_SAFETY_VM_MOD_TAG);
		multiboot_rqmid_39353_linux_mod(mod_idx);
		multiboot_rqmid_39358_second_boot(mod_idx);
		multiboot_rqmid_39375_multiboot_flags(mbi->mi_flags);
		multiboot_rqmid_39376_boot_modules(mbi->mi_mods_count);
		multiboot_rqmid_39377_memory_map(mbi);
		multiboot_rqmid_39380_memory_map(mods);
		multiboot_rqmid_39381_machine_state();
	}

	//safety
	if (vm->vm_id == 0)	{
		mod_idx = get_mod_idx_by_tag(mods, mbi->mi_mods_count, SAFETY_VM_MOD_TAG);
		multiboot_rqmid_39355_zephyr_mod(mod_idx);
		multiboot_rqmid_39359_first_boot(mod_idx);
		multiboot_rqmid_39375_multiboot_flags(mbi->mi_flags);
		multiboot_rqmid_39376_boot_modules(mbi->mi_mods_count);
		multiboot_rqmid_39377_memory_map(mbi);
		multiboot_rqmid_39395_memory_map(mods);
		multiboot_rqmid_39381_machine_state();
	}

	switch (sw_info->kernel_type) {
	case KERNEL_BZIMAGE:
		zeropage = (struct zero_page *)hpa2hva((uint64_t)mods[1].mm_mod_start);
		multiboot_rqmid_39356_pref_address(zeropage);
		multiboot_rqmid_39357_relocatable_address(zeropage);
		multiboot_rqmid_39379_non_safety_entry_point(zeropage);
		break;
	case KERNEL_ZEPHYR:
		multiboot_rqmid_39378_safety_entry_point(vm_config);
		break;
	default:
		break;
	}

	clac();
}
#endif

/**
 * @brief initialize virtual platform boot info
 *
 * @param[inout] vm a pointer to VM whose kernel loading address(guest physical address) and boot-time arguments will
 * be initialized.
 *
 * @return None
 *
 * @pre vm != NULL
 * @pre vm->vm_id < CONFIG_MAX_VM_NUM
 * @pre get_vm_config(vm->vm_id)->os_config.kernel_type == KERNEL_BZIMAGE ||
 * get_vm_config(vm->vm_id)->os_config.kernel_type == KERNEL_ZEPHYR
 * @pre (strutct multiboot_module *)hpa2hva(mbi->mi_mods_addr)->mm_mod_start > 100000H
 * @pre (strutct multiboot_module *)((unsigned int)hpa2hva(mbi->mi_mods_addr)+16H)->mm_mod_start > 100000H
 * @pre get_vm_config(0)->os_config.kernel_load_addr !=NULL
 * @pre get_vm_config(0)->os_config.kernel_entry_addr != NULL
 * @pre there exists 0 <= i <= 1 such that
 * ((struct multiboot_module *)hpa2hva((uint64_t)mbi->mi_mods_addr))[i].mm_string = "linux" and
 * ((struct zero_page *)((struct multiboot_module *)hpa2hva((uint64_t)mbi->mi_mods_addr))[i])->hdr.pref_addr != NULL
 * @pre hpa2hva(boot_regs[0]) == MULTIBOOT_INFO_MAGIC
 * @pre hpa2hva((uint64_t)boot_regs[1]) != NULL
 * @pre ((struct multiboot_info *)hpa2hva((uint64_t)boot_regs[1])->mi_flags & MULTIBOOT_INFO_HAS_MODS) != 0
 * @pre get_vm_config(vm->vm_id)->os_config.kernel_mod_tag != NULL
 *
 * @mode HV_SUBMODE_INIT_ROOT
 *
 * @reentrancy unspecified
 * @threadsafety \a vm is different among parallel invocation
 */
void init_vm_boot_info(struct acrn_vm *vm)
{
	/** Declare the following local variables of type struct multiboot_info *.
	 *  - mbi representing the multiboot information structure given from the boot_regs which saves multiboot
	 *  information pointer, initialized as hpa2hva(boot_regs[1]). */
	struct multiboot_info *mbi = (struct multiboot_info *)hpa2hva((uint64_t)boot_regs[1]);
	/** Declare the following local variables of type struct acrn_vm_config *.
	 *  - vm_config representing the virtual platform configuration structure of the given VM. */
	struct acrn_vm_config *vm_config;
	/** Declare the following local variables of type struct multiboot_module *.
	 *  - mods representing the module structure array whose elements comply with multiboot protocol. */
	struct multiboot_module *mods;
	/** Declare the following local variables of type uint32_t.
	 *  - mod_idx representing the index of the module structure array. */
	uint32_t mod_idx;

	/** Call stac in order to set the AC flag bit in the EFLAGS register and make the supervisor-mode data have
	 *  rights to access the user-mode pages even if the SMAP bit is set in the CR4 register.*/
	stac();
	/** Logging the following information with a log level of ACRN_DBG_BOOT.
	 *  - mbi->mi_flags */
	dev_dbg(ACRN_DBG_BOOT, "Multiboot detected, flag=0x%x", mbi->mi_flags);

	/** Set vm_config to the virtual platform configuration structure of the given VM */
	vm_config = get_vm_config(vm->vm_id);
	/** set mods to the host virtual address translated from the mi_mods_addr field of mbi.*/
	mods = (struct multiboot_module *)hpa2hva((uint64_t)mbi->mi_mods_addr);

	/** Logging the following information with a log level of ACRN_DBG_BOOT.
	 *  - mbi->mi_mods_count */
	dev_dbg(ACRN_DBG_BOOT, "mod counts=%d\n", mbi->mi_mods_count);

	/** Set mod_idx to the index into the module structure array of mbi that matches the module tag specified
	 *  in the VM configuration for vm. */
	mod_idx = get_mod_idx_by_tag(mods, mbi->mi_mods_count, vm_config->os_config.kernel_mod_tag);
	/** Call init_vm_kernel_info with the following parameters, in order to initialize the kernel_info field and
	 *  the kernel_type field of vm->sw field.
	 *  - vm
	 *  - &mods[mod_idx] */
	init_vm_kernel_info(vm, &mods[mod_idx]);
	/** Call init_vm_bootargs_info with the following parameters, in order to initialize the bootargs_info field
	 *  of vm->sw field.
	 *  - vm */
	init_vm_bootargs_info(vm);
	/** Call clac in order to clear the AC bit in the EFLAGS register and make the supervisor-mode data do not
	 *  have rights to access the user-mode pages*/
	clac();

#ifdef MULTIBOOT_NATIVE_TEST
	srs_multiboot_test(vm);
#endif
}

/**
 * @}
 */
