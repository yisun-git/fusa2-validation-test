#include<stdio.h>
#include <fcntl.h>
#include <unistd.h>

unsigned char buff[1024];

unsigned char multiboot_checksum(void *point, unsigned long size)
{
	unsigned char sum = 0;
	unsigned char *p = (unsigned char *)point;
	unsigned long i;

	for (i = 0; i < size; i++) {
		sum += p[i];
	}

	return sum;
}

int main(int argc, char ** argv)
{
	int fd;
	ssize_t size;
	unsigned char checksum=0;

	if(argc != 2) {
		printf("usage: checksum file_name\n");
		return 1;
	}

	fd = open(argv[1], O_RDONLY);
	if(fd == -1) {
		printf("open %s file error\n", argv[1]);
		return fd;
	}

	while((size = read(fd, buff, 1024)) != 0) {
		checksum += multiboot_checksum(buff, size);
	}

	printf("checksum=0x%x\n", checksum);
	close(fd);

	return 0;
}

